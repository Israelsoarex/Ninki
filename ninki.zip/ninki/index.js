function countdown(dateString, element) {
  let countDownDate = new Date(dateString).getTime();
  let x = setInterval(function() {
    let now = new Date().getTime();
    let distance = countDownDate - now;
    let days = String(Math.floor(distance / (1000 * 60 * 60 * 24))).padStart(2, '0');
    let hours = String(Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))).padStart(2, '0');
    let minutes = String(Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))).padStart(2, '0');
    let seconds = String(Math.floor((distance % (1000 * 60)) / 1000)).padStart(2, '0');
    element.innerHTML = '<div class="time"><span id="dia">' + days + '</span><span class="time-txt" style="color: #97CB42">DIAS</span></div>' +
                        '<div class="time"><span id="hora">' + hours + '</span><span class="time-txt">HRS</span></div>' +
                        '<div class="ponto">:</div>' +
                        '<div class="time"><span id="minuto">' + minutes + '</span><span class="time-txt">MIN</span></div>' +
                        '<div class="ponto">:</div>' +
                        '<div class="time"><span id="segundo">' + seconds + '</span><span class="time-txt">SEG</span></div>';
    if (distance < 0) {
      clearInterval(x);
      element.innerHTML = "A live começou!";
    }
  }, 1000);
}





let countDownDate = "2023-05-01T18:30:00Z"; // Data da live em formato de string
let countDownElement = document.querySelector(".time-div"); // Elemento HTML que exibirá a contagem regressiva
countdown(countDownDate, countDownElement);


let hamburger = document.querySelector('#hamburger')
let nav = document.querySelector('#nav')

let hidden = true;
hamburger.addEventListener("click", ()=>{
    if(hidden === true) {
        nav.style.transform = 'translateX(0%)';
        hidden = false;
    }else{
        nav.style.transform = 'translateX(100%)';
        hidden = true;
    }
})

function handleform(event) {
   event.preventDefault();
   let nome = document.querySelector('#nome').value; 
let email = document.querySelector('#email').value;
   console.log(nome, email)
    fetch('https://api.sheetmonkey.io/form/8xfAKzU7vVy3gvbHwnPf3F',{
        method:'post',
        headers : {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body:JSON.stringify({nome, email})
    }).then(mostra())
}
document.querySelector('form').addEventListener("submit", handleform)


/* function mostra() {
  const sheetId = `1A_x-nRCbkOjxdFo0KyFUBkglSQmauHSrZXG9lXWwRYE`;
  const apiKey = `AIzaSyACkpkChQCDXtLEmx2PrKY6SGRge9lHiPM`;

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/A:C?key=${apiKey}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const values = data.values;
      for (let i = 1; i < values.length; i++) { // começa do índice 1 para ignorar a primeira linha (que contém os cabeçalhos das colunas)
        const nome = values[i][0]; // primeira coluna (A) contém o nome
        const email = values[i][1]; // segunda coluna (B) contém o email

        console.log(`Nome: ${nome}, Email: ${email}`);
      }
    })
    .catch(error => {
      console.error(error);
    });
}
 */
 
 
 
 function mostra() {
  const sheetId = `1A_x-nRCbkOjxdFo0KyFUBkglSQmauHSrZXG9lXWwRYE`;
  const apiKey = `AIzaSyACkpkChQCDXtLEmx2PrKY6SGRge9lHiPM`;

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/A:C?key=${apiKey}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const values = data.values;
      let emails = [];
      for (let i = 1; i < values.length; i++) { // começa do índice 1 para ignorar a primeira linha (que contém os cabeçalhos das colunas)
        const nome = values[i][0]; // primeira coluna (A) contém o nome
        const email = values[i][1]; // segunda coluna (B) contém o email
        emails.push(email);
       // console.log(`Nome: ${nome}, Email: ${email}`);
      }
      const emailSorteado = emails[Math.floor(Math.random() * emails.length)]; // seleciona um email aleatório
      const quantidade = emails.filter(e => e === emailSorteado).length; // conta quantas vezes o email sorteado aparece na planilha
      console.log(`O email sorteado foi ${emailSorteado}, presente ${quantidade} vezes na planilha.`);
    })
    .catch(error => {
      console.error(error);
    });
}
